/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.u1a4_siyathdesilva;

/**
 *
 * @author 350302390
 */
public class U1A4_Siyathdesilva {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
